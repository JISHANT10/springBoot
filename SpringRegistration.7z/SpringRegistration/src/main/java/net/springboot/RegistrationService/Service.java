package net.springboot.RegistrationService;

import org.springframework.beans.factory.annotation.Autowired;

import net.springboot.RegistrationModel.User;
import net.springboot.UserRepository.Repository;

@org.springframework.stereotype.Service
public class Service {
	
	@Autowired
	private Repository repo;
	
	public User saveUser(User user) {
		return repo.save(user);
	}
	
	public User fetchUserByEmailId(String email) {
		return repo.findByEmailId(email);
	}
	
	public User fetchUserByEmailIdAndPassword(String email , String password) {
		return repo.findByEmailIdAndPassword(email, password);
	}

}
