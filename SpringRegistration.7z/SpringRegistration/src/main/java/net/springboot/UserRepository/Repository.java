package net.springboot.UserRepository;

import org.springframework.data.jpa.repository.JpaRepository;

import net.springboot.RegistrationModel.User;

public interface Repository extends JpaRepository<User, Integer>{

	public User findByEmailId(String emailId);
	public User findByEmailIdAndPassword(String emailId , String password);

}