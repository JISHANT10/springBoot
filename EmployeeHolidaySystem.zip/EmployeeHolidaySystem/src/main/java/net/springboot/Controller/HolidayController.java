package net.springboot.Controller;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import net.springboot.Model.Holiday;
import net.springboot.Repository.HolidayRepository;

@RestController
@RequestMapping("api/v1/")
public class HolidayController {
	
	@Autowired
	HolidayRepository repository;

	
	@PostMapping("/holiday")
	public Holiday saveHolidays(@RequestBody Holiday holiday) {
		System.out.println(holiday.getTitle());
		return repository.save(holiday);
	}
	
	@GetMapping("/holiday")
	public List<Holiday> getHolidays(){
		
			return repository.findAll();
	}
	
	@DeleteMapping("/holiday/{id}")
	public Holiday deleteHoliday(@PathVariable("id") Long id) {
			
		Holiday existingHoliday = repository.findById(id).orElseThrow();
		repository.delete(existingHoliday);
		return existingHoliday;
	}
	
	@PutMapping("holiday/{id}")
	@Transactional
	public Holiday saveHoliday(@PathVariable("id") Long id , @RequestBody Holiday newHoliday) {
			
		Holiday oldHoliday = repository.findById(id).orElseThrow();
		oldHoliday.setTitle(newHoliday.getTitle());
		oldHoliday.setDate(newHoliday.getDate());
		return oldHoliday;
		
		
	}
	
	
	
}
